@extends('layouts.default')

@section('content')
<div class="mx-10 p-5 shadow-md rounded-md text-3xl text-gray-700">
    ยินดีต้อนรับเข้าสู่ระบบ FoodBank
</div>
{{-- @if ($product_type == 0)
 <div class="mx-10 p-5 w-full shadow-md rounded-md text-3xl text-gray-700">
     กรุณารอให้เจ้าหน้าที่เพิ่มประเภทสินค้าก่อน...
 </div>
@else
 @endif --}}
@endsection
