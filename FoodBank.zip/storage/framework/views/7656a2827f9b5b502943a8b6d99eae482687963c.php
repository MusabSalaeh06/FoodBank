

<?php $__env->startSection('content'); ?>
<div class="bg-gray-400 p-3 text-2xl shadow-md rounded-lg  mx-10 text-white font-semibold mb-5">หน้าแรก</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FoodBank\resources\views/index.blade.php ENDPATH**/ ?>