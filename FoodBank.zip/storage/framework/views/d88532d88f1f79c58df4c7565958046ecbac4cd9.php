

<?php $__env->startSection('content'); ?>

<?php if(session('error')): ?>
<div class="bg-red-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('error')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('store')): ?>
<div class="bg-green-500 p-5 text-xl mx-10 text-white shadow-lg font-semibold rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('store')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('update')): ?>
<div class="bg-yellow-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('update')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('delete')): ?>
<div class="bg-red-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('delete')); ?></h5>
</div>
<?php endif; ?>

<div
    class="flex mx-10 mb-3 items-center justify-between p-3 mb-3 text-2xl font-semibold text-white bg-gray-400 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple">
    <div class="flex items-center">
        <span>จัดการข้อมูลการบริจาค</span>
    </div>
    
</div>
<div class="overflow-x-auto relative shadow-md sm:rounded-lg mx-10">
    <table class="w-full text-xl text-left text-gray-500 dark:text-gray-400">
        <thead class="text-2xl text-white uppercase bg-gray-400 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="py-3 px-6">
                    วันที่บริจาค
                </th>
                <th scope="col" class="py-3 px-6">
                    ผู้รับบริจาค
                </th>
                <th scope="col" class="py-3 px-6">
                    ผู้จัดส่ง
                </th>
                <th scope="col" class="py-3 px-6">
                    สถานะ
                </th>
                <th scope="col" class="py-3 px-6">
                    เจ้าหน้าที่ควบคุม
                </th>
                 <th scope="col" class="py-3 px-6">
                    <span class="sr-only" width="5%">ดูรายละเอียด</span>
                </th> 
                <th scope="col" class="py-3 px-6">
                    <span class="sr-only" width="5%">แก้ไข</span>
                </th>
                
                 <th scope="col" class="py-3 px-6" width="5%">
                    <span class="sr-only">ลบ</span>
                </th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $donate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td class="py-4 px-6">
                    <?php echo e(\Carbon\Carbon::parse($rows->created_at)->format('d/m/')); ?><?php echo e(\Carbon\Carbon::parse($rows->created_at)->format('Y')+543); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->recievers->name); ?> <?php echo e($rows->recievers->surname); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->senders->name); ?> <?php echo e($rows->senders->surname); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->status); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->admins->name); ?> <?php echo e($rows->admins->surname); ?>

                </td>
                 <td class="py-4 px-6 text-right">
                    <a href="<?php echo e(route('mission.detail',$rows->id)); ?>" class="font-medium text-gray-500 hover:text-blue-500"> 
                       ดูรายละเอียด
                    </a>
                </td> 
                <td class="py-4 px-6 text-right">
                    <a href="#" class="font-medium text-gray-500 hover:text-blue-500"> <label
                            for="edit-donate-<?php echo e($rows->id); ?>">แก้ไข</label></a>
                    <input type="checkbox" id="edit-donate-<?php echo e($rows->id); ?>" class="modal-toggle" />
                    <div class="modal">
                        <div class="modal-box">
                            <div class="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ">
                                <div class="max-w-md w-full space-y-8">
                                    <div>
                                        <img class="mx-auto h-12 w-auto"
                                            src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg"
                                            alt="Workflow">
                                        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                                            แก้ไขข้อมูลการบริจาค</h2>
                                    </div>
                                    <form action="<?php echo e(route('donate.update',$rows->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('PUT')); ?>

                                        <?php echo csrf_field(); ?>
                                        <div class="rounded-md shadow-sm -space-y-px">
                                            <div>
                                                <select name="sender" type="text"
                                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-xl rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                    <option value="<?php echo e($rows->sender ??null); ?>"><?php echo e($rows->senders->name ??null); ?> <?php echo e($rows->senders->surname ??null); ?></option>
                                                    <?php $__currentLoopData = $sender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$senders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($senders->member_id); ?>"><?php echo e($senders->name); ?> <?php echo e($senders->surname); ?> || สถานะ : <?php echo e($senders->status); ?> </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div>
                                                <select name="reciever" type="text"
                                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-xl rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                    <option value="<?php echo e($rows->reciever); ?>"><?php echo e($rows->recievers->name); ?> <?php echo e($rows->recievers->surname); ?></option>
                                                    <?php $__currentLoopData = $reciever; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$recievers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($recievers->member_id); ?>"><?php echo e($recievers->name); ?> <?php echo e($recievers->surname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <?php if($rows->status == "ส่งสำเร็จ"): ?>
                                            <?php else: ?>
                                            <div>
                                                <select name="status" type="text"
                                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-xl rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                    <option value="<?php echo e($rows->status ??null); ?>"><?php echo e($rows->status ??null); ?></option>
                                                    <option value="รอการตอบรับ">รอการตอบรับ</option>
                                                    <option value="หมดเวลา">หมดเวลา</option>
                                                </select>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <button type="submit"
                                                class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-xl font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                                                </span>
                                                อัพเดท
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="modal-action">
                                <label for="edit-donate-<?php echo e($rows->id); ?>"
                                    class="bg-red-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150">ปิด</label>
                            </div>

                        </div>
                    </div>
                </td>
                 <td class="py-4 px-6 text-right">
                    <form action="<?php echo e(route('donate.delete',$rows->id)); ?>" class="nav-link dropdown" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="font-medium text-gray-500 hover:text-blue-500"
                            onclick="return confirm('คุณต้องการลบการบริจาคหรือไม่?')">
                            ลบ</button>
                    </form>
                </td> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FoodBank\resources\views/Donate.blade.php ENDPATH**/ ?>