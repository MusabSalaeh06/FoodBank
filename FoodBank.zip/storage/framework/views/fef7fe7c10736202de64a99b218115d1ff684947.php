
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        body {
                font-family: "TH SarabunPSK";
            }
    </style>
</head>
<body>


    <nav class="flex items-center justify-between flex-wrap bg-red-400 p-6">
        <div class="flex items-center flex-no-shrink text-white mr-6">
          <span class="font-semibold text-3xl tracking-tight">
            FoodBank
          </span>
        </div>
        <div class="block lg:hidden">
          <button data-toggle-hide="[data-nav-content]" class="
              flex items-center px-3 py-2 border rounded 
              text-teal-lighter border-teal-light hover:text-white
              hover:border-white rounded focus:outline-none 
              focus:shadow-outline
            ">
            <svg class="fill-current h-3 w-3" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <title>
                Menu
              </title>
              <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
            </svg>
          </button>
        </div>
      
        <div data-nav-content="" class="
            w-full block flex-grow lg:flex lg:items-center lg:w-auto
            hidden lg:block
          ">
          <div class="text-2xl text-white font-semibold lg:flex-grow">
          </div>
          <div class="text-2xl text-white font-semibold  lg:flex-shrink">
            <a href="/login" class="
                block mt-4 lg:inline-block lg:mt-0 text-teal-lighter 
                hover:text-white mr-4 rounded focus:outline-none 
                focus:shadow-outline
              ">
              <button class="text-white bg-red-500 text-center inline-flex items-center rounded-lg shadow-md p-2 text-2xl" 
                type="button">เข้าสู่ระบบ
              </button>
            </a>
            <a href="/register" class="
                block mt-4 lg:inline-block lg:mt-0 text-teal-lighter 
                hover:text-white mr-4 rounded focus:outline-none 
                focus:shadow-outline
              ">
              <button class="text-white bg-red-500 text-center inline-flex items-center rounded-lg shadow-md p-2 text-2xl" 
                type="button">สร้างบัญชีผู้ใช้ใหม่
              </button>
            </a>
            
          </div>
        </div>
      </nav>
     
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <script>
            document.querySelector('[data-toggle-hide]').addEventListener('click', function() {
  console.log(this.dataset);
  document
    .querySelector(this.dataset.toggleHide)
    .classList
    .toggle('hidden');
});
        </script>
</body>
</html>

<?php /**PATH C:\laragon\www\FoodBank\resources\views/layouts/app.blade.php ENDPATH**/ ?>