

<?php $__env->startSection('content'); ?>

<?php if(session('error')): ?>
<div class="bg-red-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('error')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('store')): ?>
<div class="bg-green-500 p-5 text-xl mx-10 text-white shadow-lg font-semibold rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('store')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('update')): ?>
<div class="bg-yellow-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('update')); ?></h5>
</div>
<?php endif; ?>

<?php if(session('delete')): ?>
<div class="bg-red-500 p-5 text-xl mx-10 text-white font-semibold shadow-lg rounded-lg mb-3" role="alert">
    <h5><?php echo e(session('delete')); ?></h5>
</div>
<?php endif; ?>

<div
    class="flex mx-10 mb-3 items-center justify-between p-3 mb-3 text-2xl font-semibold text-white bg-gray-400 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple">
    <div class="flex items-center">
        <span>จัดการข้อมูลผู้บริจาค</span>
    </div>
    <label
        class="bg-red-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
        type="button" for="add-giver">
        เพิ่มข้อมูล
    </label>
    <input type="checkbox" id="add-giver" class="modal-toggle" />
    <div class="modal">
        <div class="modal-box">
            <div class="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ">
                <div class="max-w-md w-full space-y-8">
                    <div>
                        <img class="mx-auto h-12 w-auto"
                            src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg" alt="Workflow">
                        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">เพิ่มข้อมูลผู้บริจาค</h2>
                    </div>
                    <form class="mt-8 space-y-6" action="<?php echo e(route('member.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="remember" value="true">
                        <div class="rounded-md shadow-sm -space-y-px">
                            <div>
                                <input name="email" type="email" autocomplete="email" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="อีเมล">
                            </div>
                            <div>
                                <input name="password" type="password" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="รหัสผ่าน">
                            </div>
                            <div>
                                <input name="password_confirmation" type="password" autocomplete="current-password"
                                    required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ยืนยันรหัสผ่าน">
                            </div>
                            <div>
                                <input name="name" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ชื่อ">
                            </div>
                            <div>
                                <input name="surname" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="นามสกุล">
                            </div>
                            <div>
                                <input name="tel" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="้เบอร์โทรศัพท์">
                            </div>
                            <div>
                                <input name="type" type="hidden" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    value="giver">
                                
                            </div>
                            <div>
                                <input name="county" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="เขต">
                            </div>
                            <div>
                                <input name="road" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ถนน">
                            </div>
                            <div>
                                <input name="alley" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ซอย">
                            </div>
                            <div>
                                <input name="house_number" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="บ้านเลขที่">
                            </div>
                            <div>
                                <input name="group_no" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="หมู่ที่">
                            </div>
                            <div>
                                <input name="sub_district" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ตำบล">
                            </div>
                            <div>
                                <input name="district" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="อำเภอ">
                            </div>
                            <div>
                                <input name="province" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="จังหวัด">
                            </div>
                            <div>
                                <input name="ZIP_code" type="text" autocomplete="current-password" required
                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                    placeholder="ไปรษณีย์">
                            </div>
                        </div>
                        <div>
                            <button type="submit"
                                class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-xl font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                                </span>
                                บันทึก
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="modal-action">
                <label for="add-giver"
                    class="bg-red-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150">ปิด</label>
            </div>

        </div>
    </div>
</div>
<div class="overflow-x-auto relative shadow-md sm:rounded-lg mx-10">
    <table class="w-full text-xl text-left text-gray-500 dark:text-gray-400">
        <thead class="text-2xl text-white uppercase bg-gray-400 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="py-3 px-6">
                    ชื่อ-นามสกุล
                </th>
                <th scope="col" class="py-3 px-6">
                    เบอร์โทรศัพท์
                </th>
                <th scope="col" class="py-3 px-6">
                    บทบาท
                </th>
                <th scope="col" class="py-3 px-6">
                    ที่อยู่
                </th>
                <th scope="col" class="py-3 px-6">
                    อีเมล
                </th>
                <th scope="col" class="py-3 px-6">
                    <span class="sr-only" width="5%">แก้ไข</span>
                </th>
                <th scope="col" class="py-3 px-6"width="5%">
                    <span class="sr-only">ลบ</span>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $giver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td class="py-4 px-6">
                    <?php echo e($rows->name); ?> <?php echo e($rows->surname); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->tel); ?>

                </td>
                <td class="py-4 px-6">
                    <?php if( $rows->type == "giver"): ?>
                    ผู้บริจาค
                    <?php elseif( $rows->type == "reciever"): ?>
                    ผู้รับบริจาค
                    <?php elseif( $rows->type == "sender"): ?>
                    ผู้จัดส่ง
                    <?php else: ?>
                    อื่นๆ
                    <?php endif; ?>
                </td>
                <td class="py-4 px-6">
                    เขต <?php echo e($rows->county); ?> ถนน <?php echo e($rows->road); ?> ซอย <?php echo e($rows->alley); ?> บ้านเลขที่ <?php echo e($rows->house_number); ?>

                    หมู่ที่ <?php echo e($rows->group_no); ?> ตำบล <?php echo e($rows->district); ?> อำเภอ <?php echo e($rows->sub_district); ?> จังหวัด
                    <?php echo e($rows->province); ?>

                    ไปรษณีย์ <?php echo e($rows->ZIP_code); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->email); ?>

                </td>
                <td class="py-4 px-6 text-right">
                    <a href="#" class="font-medium text-gray-500 hover:text-blue-500"> <label
                            for="edit-giver-<?php echo e($rows->member_id); ?>">แก้ไข</label></a>
                    <input type="checkbox" id="edit-giver-<?php echo e($rows->member_id); ?>" class="modal-toggle" />
                    <div class="modal">
                        <div class="modal-box">
                            <div class="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ">
                                <div class="max-w-md w-full space-y-8">
                                    <div>
                                        <img class="mx-auto h-12 w-auto"
                                            src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg"
                                            alt="Workflow">
                                        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                                            แก้ไขข้อมูลผู้บริจาค</h2>
                                    </div>
                                    <form action="<?php echo e(route('member.update',$rows->member_id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('PUT')); ?>

                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="remember" value="true">
                                        <div class="rounded-md shadow-sm -space-y-px">
                                            <div>
                                                <input name="email" type="email" autocomplete="email" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->email); ?>">
                                            </div>
                                            <div>
                                                <input name="name" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->name); ?>">
                                            </div>
                                            <div>
                                                <input name="surname" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->surname); ?>">
                                            </div>
                                            <div>
                                                <input name="tel" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->tel); ?>">
                                            </div>
                                            <div>
                                                <input name="type" type="hidden" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->type); ?>">
                                                
                                            </div>
                                            <div>
                                                <input name="county" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->county); ?>">
                                            </div>
                                            <div>
                                                <input name="road" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->road); ?>">
                                            </div>
                                            <div>
                                                <input name="alley" type="text"  required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->alley); ?>">
                                            </div>
                                            <div>
                                                <input name="house_number" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->house_number); ?>">
                                            </div>
                                            <div>
                                                <input name="group_no" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->group_no); ?>">
                                            </div>
                                            <div>
                                                <input name="sub_district" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->sub_district); ?>">
                                            </div>
                                            <div>
                                                <input name="district" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->district); ?>">
                                            </div>
                                            <div>
                                                <input name="province" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->province); ?>">
                                            </div>
                                            <div>
                                                <input name="ZIP_code" type="text" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->ZIP_code); ?>">
                                            </div>
                                            <div>
                                                <input name="password" type="password" autocomplete="current-password" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->pass); ?>">
                                            </div>
                                            <div>
                                                <input name="password_confirmation" type="password" autocomplete="current-password" required
                                                    class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 text-xl"
                                                    value="<?php echo e($rows->pass); ?>">
                                            </div>
                                        </div>
                                        <div>
                                            <button type="submit"
                                                class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-xl font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                                                </span>
                                                อัพเดท
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="modal-action">
                                <label for="edit-giver-<?php echo e($rows->member_id); ?>"
                                    class="bg-red-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150">ปิด</label>
                            </div>

                        </div>
                    </div>
                </td>
                <td class="py-4 px-6 text-right">
                    <form action="<?php echo e(route('member.delete',$rows->member_id)); ?>" class="nav-link dropdown" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="font-medium text-gray-500 hover:text-blue-500"
                        onclick="return confirm('คุณต้องการลบสมาชิกที่ชื่อ <?php echo e($rows->name); ?> <?php echo e($rows->surname); ?> หรือไม่?')">
                        ลบ</button>
                    </form>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FoodBank\resources\views/Giver.blade.php ENDPATH**/ ?>