

<?php $__env->startSection('content'); ?>

<div
    class="flex mx-10 mb-3 items-center justify-between p-3 mb-3 text-2xl font-semibold text-white bg-gray-400 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple">
    <div class="flex items-center">
        <span>ข้อมูลสินค้าที่บริจาค</span>
    </div>
</div>

<div class="overflow-x-auto relative shadow-md sm:rounded-lg mx-10">
    <table class="w-full text-xl text-left text-gray-500 dark:text-gray-400">
        <thead class="text-2xl text-white uppercase bg-gray-400 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="py-3 px-6">
                    <span class="sr-only">รูปภาพ</span>
                </th>
                <th scope="col" class="py-3 px-6">
                    ชื่อสินค้า
                </th>
                <th scope="col" class="py-3 px-6">
                    ปริมาณ
                </th>
                <th scope="col" class="py-3 px-6">
                    ชื่อผู้บริจาค
                </th>
                <th scope="col" class="py-3 px-6">
                   ที่อยู่สินค้า
               </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $basket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td class="py-4 px-6">
                    <img class="m-2" src="/storage/product/product_image_assets/<?php echo e($rows->product->product_image); ?>" width="100px" height="100px">
                    
                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->product->name); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->quantity); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($rows->product->givers->name); ?> <?php echo e($rows->product->givers->surname); ?>

                </td>
                <td class="py-4 px-6">
                    เขต <?php echo e($rows->product->givers->county); ?> ถนน <?php echo e($rows->product->givers->road); ?> ซอย <?php echo e($rows->product->givers->alley); ?>

                    บ้านเลขที่ <?php echo e($rows->product->givers->house_number); ?> หมู่ที่ <?php echo e($rows->product->givers->group_no); ?> 
                    ตำบล <?php echo e($rows->product->givers->district); ?> อำเภอ <?php echo e($rows->product->givers->sub_district); ?> 
                    จังหวัด <?php echo e($rows->product->givers->province); ?> ไปรษณีย์ <?php echo e($rows->product->givers->ZIP_code); ?>

                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="overflow-x-auto relative shadow-md sm:rounded-lg mx-10 mt-3">
    <table class="w-full text-xl text-left text-gray-500 dark:text-gray-400">
        <thead class="text-2xl text-white uppercase bg-gray-400 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="py-3 px-6">
                    ที่อยู่ผู้รับบริจาค
               </th> 
            </tr>
        </thead>
        <tbody>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td class="py-4 px-6">
                    เขต <?php echo e($mission->recievers->county); ?> ถนน <?php echo e($mission->recievers->road); ?> ซอย <?php echo e($mission->recievers->alley); ?>

                    บ้านเลขที่ <?php echo e($mission->recievers->house_number); ?> หมู่ที่ <?php echo e($mission->recievers->group_no); ?> 
                    ตำบล <?php echo e($mission->recievers->district); ?> อำเภอ <?php echo e($mission->recievers->sub_district); ?> 
                    จังหวัด <?php echo e($mission->recievers->province); ?> ไปรษณีย์ <?php echo e($mission->recievers->ZIP_code); ?>

                </td>
            </tr>
        </tbody>
    </table>
</div>

<div class="overflow-x-auto relative shadow-md sm:rounded-lg mx-10 mt-3">
    <table class="w-full text-xl text-left text-gray-500 dark:text-gray-400">
        <thead class="text-2xl text-white uppercase bg-gray-400 dark:bg-gray-700 dark:text-gray-400">
            <tr> 
                <th scope="col" class="py-3 px-6" colspan="2">
                    ข้อมูลภารกิจ
                </th>
            </tr>
        </thead>
        <tbody>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <?php if($mission->image == null): ?>
                <?php else: ?>
                <td class="py-4 px-6">
                    <img class="m-2" src="/storage/donate/donate_image_assets/<?php echo e($mission->image); ?>" width="300px"
                        height="300px"> 
                </td>
                <?php endif; ?>
                 <td class="py-4 px-6" width="80%">
                    สถานะ : <?php echo e($mission->status); ?>

                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\FoodBank\resources\views/Mission_Detail.blade.php ENDPATH**/ ?>