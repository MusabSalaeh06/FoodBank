
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://unpkg.com/@themesberg/flowbite@latest/dist/flowbite.bundle.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    

    <link href="https://cdn.jsdelivr.net/npm/daisyui@2.22.0/dist/full.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>
    
    <style>
        body {
                font-family: "TH SarabunPSK";
            }
    </style>
</head>
<body>


    <nav class="flex items-center justify-between flex-wrap bg-red-400 p-6">
        <div class="flex items-center flex-no-shrink text-white mr-6">
          <a href="/">
            <span class="font-semibold text-3xl tracking-tight">
              FoodBank
            </span>
          </a>
        </div>
        <div class="block lg:hidden">
          <button data-toggle-hide="[data-nav-content]" class="
              flex items-center px-3 py-2 border rounded 
              text-teal-lighter border-teal-light hover:text-white
              hover:border-white rounded focus:outline-none 
              focus:shadow-outline
            ">
            <svg class="fill-current h-3 w-3" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <title>
                Menu
              </title>
              <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
            </svg>
          </button>
        </div>
      
        <div data-nav-content="" class="
            w-full block flex-grow lg:flex lg:items-center lg:w-auto
            hidden lg:block
          ">
          <div class="text-2xl text-white font-semibold lg:flex-grow">
            
          </div>
          <div class="text-2xl text-white font-semibold  lg:flex-shrink">
            <div class="
                block mt-4 lg:inline-block lg:mt-0 text-teal-lighter 
                hover:text-white mr-4 rounded focus:outline-none 
                focus:shadow-outline
              ">
              <?php if(Auth::user()->type == "sender"): ?>
              <div class="text-white  text-center inline-flex items-center text-2xl">
                <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->surname); ?> || สถานะ : <?php echo e(Auth::user()->status); ?> 
                <label
                class="bg-green-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 mx-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                type="button" for="edit-sender">
                อัพเดทสถานะ
                </label>
                <input type="checkbox" id="edit-sender" class="modal-toggle" />
                <div class="modal">
                    <div class="modal-box">
                        <div class="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ">
                            <div class="max-w-md w-full space-y-8">
                                <div>
                                    <img class="mx-auto h-12 w-auto"
                                        src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg"
                                        alt="Workflow">
                                    <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                                      อัพเดทสถานะ</h2>
                                </div>
                                <form action="<?php echo e(route('sender.update',Auth::user()->member_id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                    <?php echo csrf_field(); ?>
                                    <div class="rounded-md shadow-sm -space-y-px">
                                        <div>
                                            <select name="status" type="text"
                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-xl rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                <option value="<?php echo e(Auth::user()->status); ?> "><?php echo e(Auth::user()->status); ?></option>
                                                <option value="online">online</option>
                                                <option value="offline">offline</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit"
                                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-xl font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                            <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                                            </span>
                                            อัพเดท
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="modal-action">
                            <label for="edit-sender"
                                class="bg-red-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150">ปิด</label>
                        </div>
                    </div>
                </div>
              </div>  
              <?php elseif(Auth::user()->type == "admin"): ?>
              <a href="<?php echo e(route('products')); ?>">
                <button class="bg-blue-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                type="button">เลือกสินค้าบริจาค</button>
              </a>
              <a href="<?php echo e(route('basket.show')); ?>">
                <button class="bg-green-500 text-white active:bg-pink-500 font-bold uppercase text-xl px-6 py-3 mx-1 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                type="button">ตะกร้า</button>
              </a>
              <div class="text-white  text-center inline-flex items-center text-2xl">
                <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->surname); ?>

              </div>  
              <?php else: ?>
              <div class="text-white  text-center inline-flex items-center text-2xl">
                <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->surname); ?>

              </div> 
              <?php endif; ?>
            </div>
            <a href="/logout" class="
                block mt-4 lg:inline-block lg:mt-0 text-teal-lighter 
                hover:text-white mr-4 rounded focus:outline-none 
                focus:shadow-outline
              ">
              <button class="text-white bg-gray-50 text-center inline-flex items-center rounded-lg shadow-md p-2 text-3xl" 
                type="button"><box-icon name='log-out-circle'></box-icon>
              </button>
            </a>
            
          </div>
        </div>
      </nav>
     
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <script>
            document.querySelector('[data-toggle-hide]').addEventListener('click', function() {
  console.log(this.dataset);
  document
    .querySelector(this.dataset.toggleHide)
    .classList
    .toggle('hidden');
});
        </script>
</body>
</html>

<?php /**PATH C:\laragon\www\FoodBank\resources\views/layouts/default.blade.php ENDPATH**/ ?>